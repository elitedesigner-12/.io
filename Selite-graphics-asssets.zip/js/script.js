// ---- EDITABLE CONTENT ----
// Social links: replace the "#" URLs with real profiles.
const SOC=[["Instagram","IG","#"],["Behance","Be","#"],["Dribbble","Dr","#"],["LinkedIn","in","#"],["Facebook","f","#"]];
// Portfolio: set img:"path/or/data-uri" to replace the placeholder artwork on any project.
const P=[
{t:"Modern Brand Identity",c:"Branding",d:"A cohesive identity system for a growing studio.",cl:"Creative studio (sample)",o:"Build a recognizable identity that works from business cards to social media.",co:"A confident wordmark with rounded geometry and a single bold accent colour.",cd:"Minimal, editorial and high-contrast, with generous white space.",ty:"Condensed display headings with a clean geometric sans for text.",pal:["#1f4bff","#0a0f24","#ffffff","#dfe5f7"],pr:"Discovery call, moodboards, three concepts, refinement, guidelines.",re:"A complete kit of logo, stationery and social templates ready for launch.",g:"135deg,#1f4bff,#0a0f24",r:"4/5",img:"",rt:"PKR 8,000+"},
{t:"Creative Business Logo",c:"Logo Design",d:"A memorable mark built for clarity at any size.",cl:"Small business (sample)",o:"Create a simple, scalable logo that stands out in a crowded market.",co:"Monogram construction with balanced curves and sharp terminals.",cd:"Bold, simple and versatile across print and screen.",ty:"Custom-adjusted geometric sans lettering.",pal:["#0a0f24","#1f4bff","#6c8bff","#f3f6ff"],pr:"Sketching, vector build, colour tests, variation set.",re:"Primary, secondary and icon versions delivered as vector files.",g:"160deg,#6c8bff,#1f4bff",r:"1/1",img:"",rt:"PKR 5,000+"},
{t:"Luxury Event Poster",c:"Poster Design",d:"An elegant poster with striking hierarchy.",cl:"Event organiser (sample)",o:"Attract attention and communicate key event details instantly.",co:"Oversized type layered over refined curved shapes.",cd:"Luxury, dramatic and clean.",ty:"Tall condensed headline with a script accent.",pal:["#0a0f24","#ffffff","#1f4bff","#b9c8ff"],pr:"Brief, layout studies, type exploration, print-ready export.",re:"Print and social versions delivered in all required sizes.",g:"200deg,#0a0f24,#1f4bff",r:"3/4",img:"",rt:"PKR 4,000+"},
{t:"Modern Business Website",c:"Web Design",d:"A clean, responsive website UI focused on clarity.",cl:"Service business (sample)",o:"Present services clearly and turn visitors into enquiries.",co:"Airy layouts, strong typography and clear calls to action.",cd:"Modern, light and conversion-focused.",ty:"Bold headings with highly readable body text.",pal:["#ffffff","#1f4bff","#0a0f24","#f3f6ff"],pr:"Wireframes, UI design, responsive layouts, handoff.",re:"Desktop and mobile designs ready for development.",g:"120deg,#b9c8ff,#1f4bff",r:"4/3",img:"",rt:"PKR 15,000+"},
{t:"Social Media Campaign",c:"Social Media Design",d:"A consistent set of scroll-stopping creatives.",cl:"Brand campaign (sample)",o:"Keep a campaign visually consistent across every post format.",co:"Reusable templates with one strong visual device.",cd:"Bold, consistent and instantly recognisable.",ty:"Impactful display type with concise supporting copy.",pal:["#1f4bff","#ffffff","#0a0f24","#6c8bff"],pr:"Concept, template system, batch production, export.",re:"A full campaign pack ready to schedule.",g:"45deg,#1f4bff,#6c8bff",r:"1/1",img:"",rt:"PKR 3,000+"}];
const SV=[["Logo Design","Unique and memorable logos designed to represent your brand identity with clarity, personality and professionalism.",["Logo concepts","Logo variations","Typography","Color selection","Final vector files","Brand-ready assets"],'<circle cx="12" cy="12" r="9"/><path d="M8 15l4-8 4 8M9.5 12.5h5"/>'],
["Branding","Complete visual identities that create consistency, recognition and professionalism across every touchpoint.",["Brand identity","Color palette","Typography","Business cards","Stationery","Brand guidelines","Social media identity"],'<path d="M12 3l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 16.3 6.8 19.2l1-5.9L3.5 9.2l5.9-.8z"/>'],
["Poster Design","Eye-catching promotional designs created to communicate your message and capture attention.",["Event posters","Promotional posters","Advertising graphics","Social media creatives","Campaign designs","Print-ready artwork"],'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h5"/>'],
["Web Design","Modern, clean and user-friendly website designs focused on visual impact, usability and responsive experiences.",["Landing pages","Website UI","UI/UX","Responsive layouts","Website banners","Creative web graphics"],'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>']];
const PR=[["Discover","Understand the client's business, audience, goals and requirements."],["Research","Research competitors, trends, audience and visual direction."],["Concept","Develop creative concepts and establish the visual direction."],["Design","Turn the selected concept into a polished professional design."],["Deliver","Provide final high-quality files in the required formats."]];
const WY=[["Creative Thinking","Unique ideas developed around the purpose of every project."],["Attention to Detail","Careful attention to typography, spacing, colors and composition."],["Professional Quality","Clean, polished and presentation-ready design work."],["Client Focused","Design decisions are based on the client's goals and requirements."]];
const TS=[["Sample Client A","Branding project","Editable sample testimonial. Replace with a real client's words once available.","A"],["Sample Client B","Poster design","Editable sample testimonial. Replace with a real client's words once available.","B"],["Sample Client C","Web design","Editable sample testimonial. Replace with a real client's words once available.","C"]];
// ---- RENDER ----
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
$$('[data-soc]').forEach(e=>e.innerHTML=SOC.map(s=>`<a href="${s[2]}" aria-label="${s[0]}" target="_blank" rel="noopener">${s[1]}</a>`).join(''));
$('#sg').innerHTML=SV.map((s,i)=>`<article class="sv rv"><span class="n">0${i+1}</span><div class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${s[3]}</svg></div><h3 class="d">${s[0]}</h3><p>${s[1]}</p><ul>${s[2].map(x=>`<li>${x}</li>`).join('')}</ul><a class="btn o" href="#/contact" data-svc="${s[0]}">Explore Service</a></article>`).join('');
$('#tl').innerHTML=PR.map((s,i)=>`<div class="stp rv"><div class="nn">0${i+1}</div><div class="c"><h3 class="d">${s[0]}</h3><p>${s[1]}</p></div></div>`).join('');
$('#wg').innerHTML=WY.map((s,i)=>`<div class="wy rv"><span class="k">0${i+1}</span><h3 class="d">${s[0]}</h3><p>${s[1]}</p></div>`).join('');
$('#tg').innerHTML=TS.map(s=>`<figure class="tm rv" style="margin:0"><p>${s[2]}</p><figcaption class="who"><div class="av" aria-hidden="true">${s[3]}</div><div><b>${s[0]}</b><span>${s[1]}</span></div></figcaption></figure>`).join('');
$('#rd').innerHTML=["Email","WhatsApp","Phone Call","Video Call"].map((m,i)=>`<label><input type="radio" name="Preferred Contact Method" value="${m}" ${i?'':'checked'}><span>${m}</span></label>`).join('');
const cats=["All",...new Set(P.map(p=>p.c))];let cur="All";
const art=(p,x='')=>`<div class="art" style="--r:${p.r};background-image:${p.img?`url(${p.img})`:`linear-gradient(${p.g})`}" role="img" aria-label="${p.t} preview">${p.img?'':x||p.t.split(' ').map(w=>w[0]).join('')}</div>`;
function grid(){
  $('#fl').innerHTML=cats.map(c=>`<button aria-pressed="${c==cur}" data-c="${c}">${c.toUpperCase()}</button>`).join('');
  $('#pg').innerHTML=P.map((p,i)=>({p,i})).filter(o=>cur=="All"||o.p.c==cur).map(({p,i})=>`<article class="pj">${art(p)}<div class="pi"><small>${p.c}</small><h3 class="d">${p.t}</h3><p>${p.d}</p>${p.rt?`<div class="price-tag">${p.rt}</div>`:''}${p.pin?`<a class="pin-link" href="${p.pin}" target="_blank" rel="noopener">Pinterest inspiration ↗</a>`:''}<br><button data-i="${i}">View Project →</button></div></article>`).join('')
}
grid();
$('#fl').onclick=e=>{const b=e.target.closest('button');if(b){cur=b.dataset.c;grid()}};
const dg=$('#dg');
function open(i){const p=P[i],n=(i+1)%P.length;
$('#mb').innerHTML=`<div class="mh"><div><span class="lbl">${p.c}</span><h2 class="d" id="dgt">${p.t}</h2></div><button class="x" aria-label="Close" data-x>✕</button></div>
<div class="mk">${art(p)}${art(P[(i+1)%P.length],'Mockup 2')}${art(P[(i+2)%P.length],'Mockup 3')}</div>
<div class="dl"><div><h3>Client / Project Type</h3><p>${p.cl}</p></div><div><h3>Objective</h3><p>${p.o}</p></div><div><h3>Design Concept</h3><p>${p.co}</p></div><div><h3>Creative Direction</h3><p>${p.cd}</p></div><div><h3>Typography</h3><p>${p.ty}</p></div><div><h3>Color Palette</h3><div class="sw">${p.pal.map(c=>`<i style="background:${c}" title="${c}"></i>`).join('')}</div></div><div><h3>Design Process</h3><p>${p.pr}</p></div><div><h3>Final Result</h3><p>${p.re}</p></div></div>
<div class="mn2"><button class="btn o" data-x>Back to Portfolio</button><button class="btn" data-i="${n}">Next Project →</button></div>`;
dg.showModal();dg.scrollTop=0;$('#mb').scrollTop=0}
document.addEventListener('click',e=>{const b=e.target.closest('[data-i]');if(b)open(+b.dataset.i);if(e.target.closest('[data-x]')||e.target===dg)dg.close()});
// ---- ROUTER ----
const nav=$('#nav'),bg=$('#bg');
function route(){let p=(location.hash.replace('#/','')||'home');const ok=['home','about','services','portfolio','process','contact'];if(!ok.includes(p))p='home';
$$('[data-p]').forEach(s=>s.hidden=!s.dataset.p.split(' ').includes(p));
$$('nav a').forEach(a=>a.classList.toggle('on',a.getAttribute('href')=='#/'+p));
nav.classList.remove('open');bg.setAttribute('aria-expanded','false');dg.open&&dg.close();
document.title=(p=='home'?'':p[0].toUpperCase()+p.slice(1)+' | ')+'Muqeet Ahmad Cheema | Elite Graphic Designer';
scrollTo(0,0);watch()}
addEventListener('hashchange',route);
bg.onclick=()=>{const o=nav.classList.toggle('open');bg.setAttribute('aria-expanded',o)};
// ---- MOTION ----
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);if(e.target.id=='st')count()}}),{threshold:.15});
function watch(){$$('.rv:not(.in)').forEach(e=>io.observe(e));const st=$('#st');if(st&&!st.dataset.d)io.observe(st)}
function count(){const st=$('#st');st.dataset.d=1;$$('#st [data-n]').forEach(b=>{const n=+b.dataset.n,t=performance.now();(function f(now){const k=Math.min((now-t)/1400,1);b.textContent=Math.round(n*(1-Math.pow(1-k,3)))+b.dataset.s;if(k<1)requestAnimationFrame(f)})(t)})}
route();addEventListener('load',()=>setTimeout(()=>$('#ld').classList.add('g'),400));

/* ===== ADMIN: browser-side portfolio/rate manager ===== */
const ADMIN_PASSWORD="123098";
const AKEY="mac_admin_items_v1", RKEY="mac_rates_v1";
const loadA=()=>{try{return JSON.parse(localStorage.getItem(AKEY)||"[]")}catch{return[]}};
const saveA=a=>localStorage.setItem(AKEY,JSON.stringify(a));
const loadR=()=>{try{return JSON.parse(localStorage.getItem(RKEY)||"{}")}catch{return{}}};
const saveR=r=>localStorage.setItem(RKEY,JSON.stringify(r));

function applyAdminData(){
  const added=loadA();
  // Added items are shown first, then the built-in portfolio.
  added.forEach(x=>{ if(x && x.img) P.unshift({...x,custom:true}); });
  const rates=loadR();
  SV.forEach(s=>{ if(rates[s[0]]) s.rate=rates[s[0]]; });
  $('#sg').innerHTML=SV.map((s,i)=>`<article class="sv rv"><span class="n">0${i+1}</span><div class="ic"><svg viewBox="0 0 24 24" aria-hidden="true">${s[3]}</svg></div><h3 class="d">${s[0]}</h3><p>${s[1]}</p><ul>${s[2].map(x=>`<li>${x}</li>`).join('')}</ul>${s.rate?`<div class="price-tag">Starting ${s.rate}</div>`:''}<a class="btn o" href="#/contact" data-svc="${s[0]}">Explore Service</a></article>`).join('');
  cats.splice(0,cats.length,...["All",...new Set(P.map(p=>p.c))]);
  grid();
}

function renderRateEditor(){
  const rates=loadR();
  $('#rateEditor').innerHTML=SV.map(s=>`<div class="f"><label>${s[0]}</label><input class="rate-input" data-rate="${s[0]}" value="" placeholder="e.g. PKR 5,000+"></div>`).join('');
  $$('.rate-input').forEach(i=>i.value=rates[i.dataset.rate]||"");
}
function renderAdminList(){
  const a=loadA();
  $('#adminList').innerHTML=a.length?a.map((x,i)=>`<div class="admin-item"><img src="${x.img}" alt=""><div><b>${x.t}</b><small>${x.c} · ${x.rt||'No rate'}</small></div><div class="admin-actions"><button data-del="${i}">Delete</button></div></div>`).join(''):'<p style="color:var(--mut)">No custom items added yet.</p>';
}
function openAdmin(){ $('#adminDialog').showModal(); $('#adminLogin').hidden=false; $('#adminApp').hidden=true; $('#adminPass').value=''; $('#adminErr').textContent=''; }
$('#adminFab').onclick=openAdmin;
$('#adminClose').onclick=()=>$('#adminDialog').close();
$('#adminDialog').addEventListener('click',e=>{if(e.target===e.currentTarget)e.currentTarget.close()});
$('#adminLoginBtn').onclick=()=>{
  if($('#adminPass').value===ADMIN_PASSWORD){$('#adminLogin').hidden=true;$('#adminApp').hidden=false;renderRateEditor();renderAdminList();}
  else $('#adminErr').textContent='Incorrect password.';
};
$('#adminPass').addEventListener('keydown',e=>{if(e.key==='Enter')$('#adminLoginBtn').click()});
$('#aAdd').onclick=()=>{
  const file=$('#aImg').files[0], title=$('#aTitle').value.trim();
  if(!file||!title){alert('Please add a project title and image.');return}
  const reader=new FileReader();
  reader.onload=()=>{
    const item={t:title,c:$('#aCat').value,d:'Custom portfolio project.',cl:'Custom project',o:'Portfolio showcase.',co:'Added from Admin Panel.',cd:'As uploaded.',ty:'As designed.',pal:['#1f4bff','#0a0f24','#ffffff'],pr:'Uploaded through the admin panel.',re:'Custom portfolio item.',g:'135deg,#1f4bff,#0a0f24',r:'4/3',img:reader.result,rt:$('#aRate').value.trim(),pin:$('#aPin').value.trim()};
    const a=loadA();a.push(item);saveA(a);location.reload();
  };
  reader.readAsDataURL(file);
};
$('#aClear').onclick=()=>{if(confirm('Remove all custom portfolio items from this browser?')){localStorage.removeItem(AKEY);location.reload()}};
$('#saveRates').onclick=()=>{
  const r={};$$('.rate-input').forEach(i=>{if(i.value.trim())r[i.dataset.rate]=i.value.trim()});saveR(r);alert('Rates saved on this browser.');location.reload();
};
$('#adminList').addEventListener('click',e=>{
  const b=e.target.closest('[data-del]');if(!b)return;
  const a=loadA();a.splice(+b.dataset.del,1);saveA(a);location.reload();
});
applyAdminData();

// ---- FORM ----
const V=[["nm",v=>v.trim(),"Please enter your name."],["em",v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()),"Please enter a valid email address."],["sv",v=>v,"Please select a service."],["pd",v=>v.trim(),"Please describe your project."]];
$('#fm').addEventListener('submit',e=>{e.preventDefault();let bad=null;
V.forEach(([id,fn,msg])=>{const el=$('#'+id),er=$('#e-'+id),ok=fn(el.value);el.setAttribute('aria-invalid',!ok);er.textContent=ok?'':msg;if(!ok&&!bad)bad=el});
const ag=$('#ag');$('#e-ag').textContent=ag.checked?'':'Please agree to be contacted so I can reply to your inquiry.';if(!ag.checked&&!bad)bad=ag;
if(bad){bad.focus();return}
const f=new FormData(e.target),g=k=>(f.get(k)||'Not provided');
const body=`NEW PROJECT INQUIRY\n\nClient Name:\n${g('Client Name')}\n\nClient Email:\n${g('Client Email')}\n\nPhone / WhatsApp:\n${g('Phone / WhatsApp')}\n\nCompany:\n${g('Company')}\n\nService:\n${g('Service')}\n\nProject Title:\n${g('Project Title')}\n\nPreferred Date:\n${g('Preferred Date')}\n\nPreferred Time:\n${g('Preferred Time')}\n\nPreferred Contact Method:\n${g('Preferred Contact Method')}\n\nBudget:\n${g('Budget')}\n\nDeadline:\n${g('Deadline')}\n\nProject Description:\n${g('Project Description')}\n\nAdditional Information:\n${g('Additional Information')}`;
// No credentials live in this page. To deliver inquiries (and the client confirmation email) automatically,
// POST this data to a secure backend or form service instead. Fallback below opens the visitor's email app.
location.href='mailto:ahmadmuqeet788@gmail.com?subject='+encodeURIComponent('New Project Inquiry — Muqeet Ahmad Cheema')+'&body='+encodeURIComponent(body);
$('#fw').hidden=true;$('#ok').hidden=false;$('#ok').focus();$('#card').scrollIntoView({behavior:'smooth',block:'center'})});
$('#fm').addEventListener('input',e=>{const t=e.target;if(t.getAttribute('aria-invalid')){t.setAttribute('aria-invalid','false');const er=$('#e-'+t.id);er&&(er.textContent='')}});
