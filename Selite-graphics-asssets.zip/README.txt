MUQEET AHMAD CHEEMA WEBSITE

Folders:
css/    - website CSS
js/     - website JavaScript
logo/   - logos
fonts/  - local font files
image/  - website images

The HTML file is organized to load css/style.css and js/script.js.
Add your logo files to logo/, fonts to fonts/, and images to image/.
